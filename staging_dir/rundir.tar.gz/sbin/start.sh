
# get topdir
 
export PERL=/usr/bin/lua ;export SRCDIR=/; ~/rundir/bin/lighttpd -f ~/rundir/etc/lighttpd.conf
